import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recepie-details',
  templateUrl: './recepie-details.component.html',
  styleUrls: ['./recepie-details.component.css']
})
export class RecepieDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
