export const environment = {
  production: true,
  firebase : {
    apiKey: "AIzaSyAvmVkeKjo9A9pK9pWUxvRef-_bvKcqgJM",
    authDomain: "recepielist.firebaseapp.com",
    databaseURL: "https://recepielist.firebaseio.com",
    projectId: "recepielist",
    storageBucket: "",
    messagingSenderId: "865613033128"
  }
};
